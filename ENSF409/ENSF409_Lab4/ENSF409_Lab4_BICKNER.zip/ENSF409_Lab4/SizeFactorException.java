/**
 * name
 */
public class SizeFactorException extends Exception{
    public SizeFactorException(){
        super("\n------Error in resizable factor-----");
    }
}