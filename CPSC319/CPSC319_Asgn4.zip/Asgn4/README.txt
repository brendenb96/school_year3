README
---- CPSC319 Assignment 4 ----
Brenden Bickner 
10148167

Command line argument format to compile is:
javac Assign4.java BFS.java DFS.java

Command line argument format to run is:
java Assign4 (input.txt) (query.txt) (depth_out.txt) (breadth_out.txt)

Didn't do the bonus part