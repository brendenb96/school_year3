
---- README ----
CPSC 319 Assignment 3
Brenden Bickner 10148167
------------------------------------------------------------------------------------------------------

compile with - javac Assign3.java BinaryTree.java LinkedListQueue.java SinglyLinkedList.java Node.java

run with - java Assign3 input output1 output2

Did not do the bonus part.