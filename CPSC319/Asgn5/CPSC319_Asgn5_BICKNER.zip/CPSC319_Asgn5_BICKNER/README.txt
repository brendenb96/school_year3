README

Brenden Bickner
10148167

compile with:
javac HashTable.java Assign5.java

run with:
java Assign5 input.txt output.txt

I didnt do the extra part